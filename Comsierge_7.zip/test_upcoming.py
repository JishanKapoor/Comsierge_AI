import unittest
from datetime import datetime
import upcoming

class TestFailedEdgeCases(unittest.TestCase):

    def setUp(self):
        upcoming.contacts = {
            "+14372392448": {"name": "John Doe", "messages": [], "upcoming": []}
        }
        upcoming.current_contact = None

    def test_failed_edge_cases(self):
        # Edge case 17: Reschedule to same time
        with self.subTest(msg="Reschedule to same time"):
            upcoming.current_contact = "+14372392448"
            upcoming.contacts["+14372392448"]["upcoming"] = [
                {"timestamp": datetime.now(), "time": datetime(2025, 7, 22, 21, 0), "description": "Meeting",
                 "status": "unconfirmed", "reason": None}
            ]
            upcoming.update_upcoming("reschedule", datetime(2025, 7, 22, 21, 0), "Meeting", "received", "reschedule to 9 pm")
            events = upcoming.contacts["+14372392448"]["upcoming"]
            self.assertEqual(len(events), 1)
            self.assertEqual(events[0]["status"], "rescheduled")

        # Edge case 20: No contact selected
        with self.subTest(msg="No contact selected"):
            upcoming.current_contact = None
            upcoming.update_upcoming("propose", datetime(2025, 7, 22, 21, 0), "Meeting", "sent", "meeting at 9 pm")
            self.assertEqual(len(upcoming.contacts["+14372392448"]["upcoming"]), 0)

if __name__ == '__main__':
    unittest.main()