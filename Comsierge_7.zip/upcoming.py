import os
from datetime import datetime, timedelta
import json
from openai import AzureOpenAI
import pytz
from bson import ObjectId
from db import store
import logging
import threading
from bson.objectid import ObjectId as NewObjectId
import time

# Configure logging
logger = logging.getLogger(__name__)

# Set default TERM if unset to suppress errors
if "TERM" not in os.environ:
    os.environ["TERM"] = "xterm"

# Initialize Azure OpenAI client
client = AzureOpenAI(
    azure_endpoint="https://callnowusa.openai.azure.com/",
    api_key="1JlJLWNSeUNZXD4QnrDuXPHS34Lj8xgowfo9jQp9K1Kz7LNvj6b7JQQJ99BFACYeBjFXJ3w3AAABACOGQOIQ",
    api_version="2025-01-01-preview"
)
deployment_name = "gpt-4.1"

def cleanup_past_events():
    """Remove events that are more than 4 hours in the past."""
    now = datetime.now(pytz.UTC)
    try:
        result = store.db.upcoming_events.delete_many({
            'proposed_time': {'$lt': now - timedelta(hours=4)}
        })
        logger.debug(f"Cleaned up {result.deleted_count} past events.")
    except Exception as e:
        logger.error(f"Error cleaning up past events: {str(e)}")

def extract_time_and_intent(message, phone_id, from_number, to_number):
    """Analyze a message to detect meeting-related intent and time using Azure OpenAI."""
    for attempt in range(5):
        try:
            current_date = datetime.now(pytz.UTC).strftime("%Y-%m-%d")
            response = client.chat.completions.create(
                model=deployment_name,
                messages=[
                    {
                        "role": "system",
                        "content": f"""
                            You are an assistant that analyzes messages to detect meeting-related intents and extract meeting times.
                            - Today's date is {current_date}.
                            - The input includes recent conversation history followed by the current message, formatted as:
                              <timestamp> (sent/received): <message>
                              ...
                              Current message: <current_message>
                            - Use the conversation history to determine the context of the current message.
                            - If the current message is short and contains only a time (e.g., "at 7?", "8 pm"), treat it as a rescheduling or confirmation of the most recent unconfirmed meeting proposal in the conversation history. Use the date from the most recent proposal and apply the specified time. If no date is specified in the history, assume today.
                            - Identify if the current message implies a meeting proposal, confirmation, rescheduling, or cancellation.
                            - Extract specific dates (e.g., "2 August" as "2025-08-02") or relative dates (e.g., "next Monday", "tomorrow") from the current message.
                            - For "at X" or "today at X" (e.g., "at 9"), assume X is the hour in 24-hour format for today.
                              - If AM/PM is not specified and the current time is past X:00 AM, interpret as X:00 PM.
                              - If the time is in the past by more than 4 hours or not on the current day (unless specified in context), return null for time.
                            - For "tomorrow at X", assume X is the hour for the next day.
                            - For specific dates like "2 August" or "next Monday", compute the correct date in 2025 or 2026 if specified.
                            - For vague rescheduling (e.g., "some other day"), assume the next day at 12:00.
                            - For special times like "midnight" (00:00), "noon" (12:00), interpret accordingly.
                            - For "next week", use exactly 7 days from today.
                            - For "next month", use exactly 30 days from today.
                            - For confirmation messages like "okay sure", "agreed", "yes sure", "does X work", or time-only messages (e.g., "at 9?"), assume they confirm the most recent unconfirmed event from the conversation history, using the specified time if provided.
                            - For rescheduling messages like "let's do it tomorrow 5 pm" or time-only messages, interpret as reschedule with the specified time, using the date from the most recent proposal if applicable.
                            - For cancellation messages like "let's cancel", interpret as cancel.
                            - For invalid times or dates (e.g., "3:30 pm", "32 august"), return time as null and intent as "propose" if meeting-related.
                            - Return a JSON string with:
                              - intent: one of "propose", "confirm", "reschedule", "cancel", or "none"
                              - time: ISO format string (e.g., "{current_date}T21:00:00Z") if a specific time is found, else null
                              - type: one of "meeting", "family_meeting", "appointment", "task", "deadline", "emergency", "other"
                        """
                    },
                    {"role": "user", "content": message}
                ],
                temperature=0.3
            )
            raw_response = response.choices[0].message.content
            logger.debug(f"Raw AI response: {raw_response}")
            try:
                result = json.loads(raw_response.strip("```json\n").rstrip("```"))
            except json.JSONDecodeError as e:
                logger.error(f"JSON parsing error: {e}, Raw response: {raw_response}")
                return {"intent": "none", "time": None, "type": "other"}

            now = datetime.now(pytz.UTC)
            current_day = now.date()
            if result["time"]:
                try:
                    result["time"] = datetime.fromisoformat(result["time"].replace("Z", "+00:00"))
                    # Allow same-day events within 4 hours in the past
                    if result["time"].date() < current_day or (result["time"] < now - timedelta(hours=4) and result["time"].date() == current_day):
                        logger.debug(f"Skipping past time: {result['time']}")
                        result["time"] = None
                except ValueError:
                    result["time"] = None
            return result
        except Exception as e:
            logger.error(f"AI processing error (attempt {attempt + 1}): {str(e)}")
            if attempt < 4:
                time.sleep(2)
                continue
            # Fallback logic for common intents
            message_lower = message.lower()
            # Check for time-only messages in context of recent events
            recent_event = store.db.upcoming_events.find_one({
                'phone_id': ObjectId(phone_id),
                'status': 'unconfirmed',
                '$or': [{'from_number': from_number}, {'to_number': to_number}],
                'created_at': {'$gte': datetime.now(pytz.UTC) - timedelta(hours=24)}
            }, sort=[('created_at', -1)])
            if recent_event and any(keyword in message_lower for keyword in ["at ", " pm", " am", "noon", "midnight"]):
                time_match = None
                event_date = recent_event.get('proposed_time', datetime.now(pytz.UTC)).date()
                if "at " in message_lower:
                    time_str = message_lower.split("at ")[-1].strip("?")
                    try:
                        hour = int(time_str)
                        if hour < 12 and datetime.now(pytz.UTC).hour > hour:
                            hour += 12  # Assume PM if past AM time
                        time_match = datetime.combine(event_date, datetime.min.time()).replace(hour=hour, tzinfo=pytz.UTC)
                    except ValueError:
                        if "noon" in time_str:
                            time_match = datetime.combine(event_date, datetime.min.time()).replace(hour=12, tzinfo=pytz.UTC)
                        elif "midnight" in time_str:
                            time_match = datetime.combine(event_date, datetime.min.time()).replace(hour=0, tzinfo=pytz.UTC)
                if time_match and time_match >= datetime.now(pytz.UTC) - timedelta(hours=4):
                    return {
                        "intent": "reschedule",
                        "time": time_match,
                        "type": "meeting"
                    }
                return {"intent": "reschedule", "time": None, "type": "other"}
            if any(keyword in message_lower for keyword in ["meeting", "schedule", "discussion"]):
                if "next week" in message_lower:
                    return {
                        "intent": "propose",
                        "time": (datetime.now(pytz.UTC) + timedelta(days=7)).replace(hour=12, minute=0, second=0, tzinfo=pytz.UTC),
                        "type": "meeting"
                    }
                if "next month" in message_lower:
                    return {
                        "intent": "propose",
                        "time": (datetime.now(pytz.UTC) + timedelta(days=30)).replace(hour=12, minute=0, second=0, tzinfo=pytz.UTC),
                        "type": "meeting"
                    }
                if "tomorrow" in message_lower:
                    if "5 pm" in message_lower:
                        return {
                            "intent": "reschedule",
                            "time": (datetime.now(pytz.UTC) + timedelta(days=1)).replace(hour=17, minute=0, second=0, tzinfo=pytz.UTC),
                            "type": "meeting"
                        }
                    return {
                        "intent": "reschedule",
                        "time": (datetime.now(pytz.UTC) + timedelta(days=1)).replace(hour=12, minute=0, second=0, tzinfo=pytz.UTC),
                        "type": "meeting"
                    }
                if "monday" in message_lower:
                    # Calculate the next Monday
                    today = datetime.now(pytz.UTC)
                    days_until_monday = (0 - today.weekday() + 7) % 7 or 7
                    next_monday = today + timedelta(days=days_until_monday)
                    return {
                        "intent": "propose",
                        "time": next_monday.replace(hour=12, minute=0, second=0, microsecond=0, tzinfo=pytz.UTC),
                        "type": "meeting"
                    }
                return {"intent": "propose", "time": None, "type": "other"}
            if any(keyword in message_lower for keyword in ["confirm", "sure", "agreed", "okay", "all good", "does", "at "]):
                return {"intent": "confirm", "time": None, "type": "other"}
            if any(keyword in message_lower for keyword in ["cancel", "terminate", "scrap", "drop"]):
                return {"intent": "cancel", "time": None, "type": "other"}
            if any(keyword in message_lower for keyword in ["reschedule", "postpone", "move"]):
                return {
                    "intent": "reschedule",
                    "time": (datetime.now(pytz.UTC) + timedelta(days=1)).replace(hour=12, minute=0, second=0, tzinfo=pytz.UTC),
                    "type": "other"
                }
            return {"intent": "none", "time": None, "type": "other"}
    return {"intent": "none", "time": None, "type": "other"}

def update_upcoming(phone_id, message_id, intent, time, type, message_type, from_number, to_number):
    """Update upcoming events in MongoDB based on intent."""
    try:
        now = datetime.now(pytz.UTC)
        alias = None
        contact = None
        if message_type == 'received':
            contact = store.db.contacts.find_one({
                'phone_id': ObjectId(phone_id),
                'phone_number': from_number
            })
            alias = contact['alias'] if contact else from_number
        else:  # sent
            contact = store.db.contacts.find_one({
                'phone_id': ObjectId(phone_id),
                'phone_number': to_number
            })
            alias = contact['alias'] if contact else to_number

        message_doc = store.db.message_log.find_one({'_id': ObjectId(message_id)})
        if message_type == 'received':
            user_message = message_doc.get('body_translated', message_doc['body'])
        else:
            user_message = message_doc.get('original_body', message_doc['body'])

        if intent == "none":
            return

        events = list(store.db.upcoming_events.find({
            'phone_id': ObjectId(phone_id),
            'status': {'$in': ['unconfirmed', 'confirmed', 'rescheduled']},
            '$or': [{'from_number': from_number}, {'to_number': to_number}]
        }).sort('updated_at', -1).limit(1))

        group_id = NewObjectId() if intent == "propose" else None

        if events:
            event = events[0]
            group_id = event.get('group_id', NewObjectId())
            if not event.get('group_id'):
                store.db.upcoming_events.update_one({'_id': event['_id']}, {'$set': {'group_id': group_id}})

        from extensions import socketio
        room = f"user_{phone_id}"

        if intent == "propose" and (time is None or time >= now - timedelta(hours=4)):
            event_data = {
                'phone_id': ObjectId(phone_id),
                'message_id': ObjectId(message_id),
                'proposed_time': time,
                'description': user_message,
                'type': type,
                'status': 'unconfirmed',
                'reason': None,
                'alias': alias,
                'from_number': from_number,
                'to_number': to_number,
                'created_at': now,
                'updated_at': now,
                'is_latest': True,
                'group_id': group_id
            }
            result = store.db.upcoming_events.insert_one(event_data)
            socketio.emit('new_event', {
                '_id': str(result.inserted_id),
                'proposed_time': time.isoformat() if time else None,
                'description': user_message,
                'type': type,
                'status': 'unconfirmed',
                'reason': None,
                'alias': alias,
                'is_latest': True,
                'group_id': str(group_id)
            }, room=room)
            logger.debug(f"Proposed new event: {user_message} for phone_id {phone_id}")

        elif intent == "confirm":
            if events:
                event = events[0]
                # If a specific time is provided, treat it as a rescheduling
                if time and time >= now - timedelta(hours=4):
                    reason = f"Rescheduled to {time.strftime('%Y-%m-%d %H:%M')}"
                    store.db.upcoming_events.update_one(
                        {'_id': event['_id']},
                        {'$set': {'status': 'rescheduled', 'reason': reason, 'updated_at': now, 'is_latest': False, 'group_id': group_id}}
                    )
                    socketio.emit('update_event', {
                        '_id': str(event['_id']),
                        'status': 'rescheduled',
                        'reason': reason,
                        'is_latest': False
                    }, room=room)
                    # Create a new unconfirmed event with the new time
                    event_data = {
                        'phone_id': ObjectId(phone_id),
                        'message_id': ObjectId(message_id),
                        'proposed_time': time,
                        'description': user_message,
                        'type': type,
                        'status': 'unconfirmed',
                        'reason': None,
                        'alias': alias,
                        'from_number': from_number,
                        'to_number': to_number,
                        'created_at': now,
                        'updated_at': now,
                        'is_latest': True,
                        'group_id': group_id
                    }
                    result = store.db.upcoming_events.insert_one(event_data)
                    socketio.emit('new_event', {
                        '_id': str(result.inserted_id),
                        'proposed_time': time.isoformat() if time else None,
                        'description': user_message,
                        'type': type,
                        'status': 'unconfirmed',
                        'reason': None,
                        'alias': alias,
                        'is_latest': True,
                        'group_id': str(group_id)
                    }, room=room)
                    logger.debug(f"Rescheduled event: {user_message} for phone_id {phone_id}")
                else:
                    # Confirm the existing event
                    store.db.upcoming_events.update_one(
                        {'_id': event['_id']},
                        {'$set': {'status': 'confirmed', 'reason': None, 'updated_at': now, 'is_latest': True, 'group_id': group_id}}
                    )
                    socketio.emit('update_event', {
                        '_id': str(event['_id']),
                        'status': 'confirmed',
                        'reason': None,
                        'is_latest': True
                    }, room=room)
                    logger.debug(f"Confirmed event: {event['description']} for phone_id {phone_id}")

        elif intent == "reschedule":
            if events:
                event = events[0]
                reason = f"Rescheduled to {(time.strftime('%Y-%m-%d %H:%M') if time else 'unspecified time')}"
                store.db.upcoming_events.update_one(
                    {'_id': event['_id']},
                    {'$set': {'status': 'rescheduled', 'reason': reason, 'updated_at': now, 'is_latest': False, 'group_id': group_id}}
                )
                socketio.emit('update_event', {
                    '_id': str(event['_id']),
                    'status': 'rescheduled',
                    'reason': reason,
                    'is_latest': False
                }, room=room)
            if time and time >= now - timedelta(hours=4):
                event_data = {
                    'phone_id': ObjectId(phone_id),
                    'message_id': ObjectId(message_id),
                    'proposed_time': time,
                    'description': user_message,
                    'type': type,
                    'status': 'unconfirmed',
                    'reason': None,
                    'alias': alias,
                    'from_number': from_number,
                    'to_number': to_number,
                    'created_at': now,
                    'updated_at': now,
                    'is_latest': True,
                    'group_id': group_id
                }
                result = store.db.upcoming_events.insert_one(event_data)
                socketio.emit('new_event', {
                    '_id': str(result.inserted_id),
                    'proposed_time': time.isoformat() if time else None,
                    'description': user_message,
                    'type': type,
                    'status': 'unconfirmed',
                    'reason': None,
                    'alias': alias,
                    'is_latest': True,
                    'group_id': str(group_id)
                }, room=room)
                logger.debug(f"Rescheduled event: {user_message} for phone_id {phone_id}")

        elif intent == "cancel":
            if events:
                event = events[0]
                store.db.upcoming_events.update_one(
                    {'_id': event['_id']},
                    {'$set': {'status': 'canceled', 'reason': 'Canceled by user', 'updated_at': now, 'is_latest': True, 'group_id': group_id}}
                )
                socketio.emit('update_event', {
                    '_id': str(event['_id']),
                    'status': 'canceled',
                    'reason': 'Canceled by user',
                    'is_latest': True
                }, room=room)
                logger.debug(f"Canceled event: {event['description']} for phone_id {phone_id}")
    except Exception as e:
        logger.error(f"Error updating upcoming event: {str(e)}")

def analyze_for_event(phone_id, message_id, direction):
    """Analyze a message for potential events and update the database."""
    try:
        message = store.db.message_log.find_one({'_id': ObjectId(message_id), 'phone_id': ObjectId(phone_id)})
        if not message:
            logger.error(f"Message {message_id} not found for phone_id {phone_id}")
            return

        from_number = message.get('from_number') if direction == 'received' else message.get('to_number')
        to_number = message.get('to_number') if direction == 'sent' else message.get('from_number')
        body = message.get('body_translated') or message.get('body')

        # Fetch recent messages for context (last 5 messages within 24 hours)
        recent_messages = list(store.db.message_log.find({
            'phone_id': ObjectId(phone_id),
            '$or': [{'from_number': from_number}, {'to_number': to_number}],
            'created_at': {'$gte': datetime.now(pytz.UTC) - timedelta(hours=24)}
        }).sort('created_at', -1).limit(5))

        # Format context for the AI
        context = "\n".join([f"{msg['created_at'].strftime('%Y-%m-%d %H:%M:%S')} ({'sent' if msg['direction'] == 'sent' else 'received'}): {msg['body_translated'] or msg['body']}" for msg in recent_messages])
        input_message = f"Recent conversation:\n{context}\nCurrent message: {body}"

        # Run AI analysis in a separate thread
        def process_event():
            try:
                result = extract_time_and_intent(input_message, phone_id, from_number, to_number)
                if result["intent"] != "none":
                    update_upcoming(
                        phone_id,
                        message_id,
                        result["intent"],
                        result["time"],
                        result["description"],
                        result["type"],
                        direction,
                        from_number,
                        to_number
                    )
            except Exception as e:
                logger.error(f"Error processing event for message {message_id}: {str(e)}")

        thread = threading.Thread(target=process_event)
        thread.start()
    except Exception as e:
        logger.error(f"Error analyzing event for message {message_id}: {str(e)}")

def get_upcoming_events(phone_id):
    """Retrieve upcoming events for a specific phone_id."""
    try:
        cleanup_past_events()
        events = list(store.db.upcoming_events.find({
            'phone_id': ObjectId(phone_id),
            'proposed_time': {'$gte': datetime.now(pytz.UTC) - timedelta(hours=4)}
        }).sort('proposed_time', 1))
        return events
    except Exception as e:
        logger.error(f"Error retrieving upcoming events for phone_id {phone_id}: {str(e)}")
        return []